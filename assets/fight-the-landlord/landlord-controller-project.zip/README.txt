FIGHT THE LANDLORD - ARDUINO CONTROLLER UPDATE

FILES
- gemini-code-1793038528517.html: your complete game with updated Arduino controls.
- LandlordController/LandlordController.ino: upload this sketch to Arduino Uno.

WIRING (Arduino Uno)
Joystick VRx -> A4
Joystick VRy -> A5 (can remain connected, but is not used)
Joystick SW -> digital pin 2
Joystick VCC -> 5V
Joystick GND -> GND
Separate mini button -> digital pin 9 and GND
You LED -> pin 4 through a 220-330 ohm series resistor; cathode -> GND
Bot 1 LED -> pin 5 through a 220-330 ohm series resistor; cathode -> GND
Bot 2 LED -> pin 6 through a 220-330 ohm series resistor; cathode -> GND

Both switches use INPUT_PULLUP: pressed means the pin connects to GND.
On a four-leg tactile button, use contacts that connect only while pressed.
Do not connect both leads to an already-connected pair of legs.

START
1. Unzip the package. Open LandlordController/LandlordController.ino in Arduino IDE.
2. Select your Arduino Uno board and USB port, then upload.
3. Close Serial Monitor and Serial Plotter so the game can use the USB port.
4. Open the downloaded HTML in desktop Chrome or Edge, outside the ChatGPT preview.
5. Click Connect Arduino and choose your Arduino's USB serial port.
   The game and sketch both use 9600 baud.
6. The page uses online Tailwind CSS, icons, and fonts, as the original did.
   Keep internet access available for its original styling.

If the browser does not expose Web Serial for a local file, serve the folder:
    python3 -m http.server 8000
Then open http://localhost:8000/gemini-code-1793038528517.html in desktop Chrome.
On Windows, use py -m http.server 8000 if python3 is not available.

CONTROLS
- Tilt left/right: move the blue highlight to another card. Return to center
  between moves. This does not select the card.
- Press the joystick straight down until it clicks: select/deselect that card.
  Selected cards rise slightly and have a gold border. You may select multiple cards.
  Cards have space between them and wrap into rows, so selecting a card does
  not cover the ranks or suits of neighboring cards.
- Press the separate mini button: play the selected cards.
- If no cards are selected, the mini button passes your current turn.
- Standard rule: you cannot pass when leading a trick. Select a legal play.
- Invalid/weaker combinations stay selected so you can adjust them.
- During AI turns, card actions are ignored.
- Bidding: mini button bids the next available value. Use the on-screen
  buttons to pass the bid or choose a different bid.
- Classic scored rules: play starts immediately after bidding.
- LEDs identify the active player. They turn off after game over/disconnection.

Left/right is now reversed to match your joystick (REVERSE_X = true).
If you later rotate or replace the joystick, set REVERSE_X = false if needed.
VRy tilting up/down does not select anything; SW is the physical click switch.
If your mini button is currently on pin 2, move it to pin 9 and put joystick SW
on pin 2. They must have separate digital inputs.

Mouse controls also work.

RULES UPDATE
The Rules button now explains every supported card pattern and scoring.
Implemented: trio+single/pair, straights, pair sequences, airplanes with no
wings/singles/pairs, four+two singles/pairs, bombs and rocket.
The same rule checker is used for human plays, AI decisions, and Hint.

This is the classic scored 1-3 bidding version. Everyone bids once; all pass
means redeal. Bid 3 ends bidding. Play starts with the landlord immediately.
Turns go You -> right Bot 2 -> left Bot 1. Two consecutive passes restore the
last player's lead. Passing does not exclude a player from later turns.

Wing settings are explicitly documented in the game: paired single wings
are allowed; wings cannot reuse the core rank. Pair wings must be distinct.
Both jokers or a whole bomb cannot be wings; an adjacent extra triple must
belong to the airplane core. Four+two singles may be a pair, but not both jokers.
These details vary among published platforms; the game uses one stated version.

Round points use bid * 2^(bombs + rockets + spring bonus). The landlord's
points are twice a farmer's points, with the opposite sign. Either farmer
finishing wins for both. Spring: no farmer has played; anti-spring: the
landlord played exactly once. No random pregame double multipliers.

REFERENCES
https://www.ourgame.com/game/lord.html
https://www.jj.cn/news/320/20110920103700018196.shtml
https://www.pagat.com/climbing/doudizhu.html

PIN CORRECTION - OCTOBER 27, 2026
The separate play button uses digital pin 9, as confirmed by the project
author. The earlier package listed pin 3. This sketch and wiring description
now match pin 9; joystick SW remains on pin 2. No new physical retest is
claimed by this documentation update.

PREVIOUS REPORTED CHECKS
The following results came with the earlier package and were not rerun
for this pin correction.
53 card-rule checks, 15 game-state checks, 14 controller/game checks, and
40 complete seeded games passed, plus simulated Web Serial connection,
packet splitting, LED writes, disconnect/reconnect and cancellation checks.
Sketch compiled as C++11 with simulated Arduino I/O; joystick latching,
independent switch debounce, one event per press and LED commands passed.
These are software simulations, not an Arduino Uno board compilation or
physical USB/wiring tests. Upload and test on your own board.

WEB SERIAL REFERENCE
https://developer.chrome.com/docs/capabilities/serial
